class Order:
    count_id = 0

    def __init__(self, customer_name, table_number, menu_items, total_price, status="Pending"):
        Order.count_id += 1
        self.__order_id = Order.count_id
        self.__customer_name = customer_name
        self.__table_number = table_number
        self.__menu_items = menu_items
        self.__total_price = total_price
        self.__status = status

    def get_order_id(self):
        return self.__order_id

    def get_customer_name(self):
        return self.__customer_name

    def get_table_number(self):
        return self.__table_number

    def get_menu_items(self):
        return self.__menu_items

    def get_total_price(self):
        return self.__total_price

    def get_status(self):
        return self.__status

    def set_customer_name(self, customer_name):
        self.__customer_name = customer_name

    def set_table_number(self, table_number):
        self.__table_number = table_number

    def set_menu_items(self, menu_items):
        self.__menu_items = menu_items

    def set_total_price(self, total_price):
        self.__total_price = total_price

    def set_status(self, status):
        self.__status = status
