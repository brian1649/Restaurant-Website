from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, json
from Forms import CreateUserForm, CreateMenuItemForm, CreateOrderForm, CreateReservationForm, LoginForm, PaymentForm
from Order import Order
from Reservation import Reservation
import stripe

from payment import Payment
import shelve, User
from functools import wraps
from datetime import datetime, date, time
from werkzeug.utils import secure_filename
from flask_mail import Mail, Message
import os

app = Flask(__name__)
app.secret_key = '!42325Sd'

stripe.api_key = "sk_test_51QrKdMRqWiizr30ML1DhTiH604UugkQc1YzSDa2NTSLs9bcqMvWnjQBvDfDWmysQ0xPCXiUz3FdSF7Z4gQtbSVDO00raje2m3D"

UPLOAD_FOLDER = 'static/images'  # ✅ Use your existing folder
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Flask-Mail Configuration
# Configure Flask-Mail with Gmail SMTP
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False
app.config['MAIL_USERNAME'] = 'lumi2402dbft@gmail.com'  # Replace with your Gmail
app.config['MAIL_PASSWORD'] = 'frac dooi zanb imhv'  # Replace with generated App Password
app.config['MAIL_DEFAULT_SENDER'] = 'lumi2402dbft@gmail.com'

mail = Mail(app)

def allowed_file(filename):
    """Check if uploaded file is an image"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in first.', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def home():
    return render_template('homelogin.html')

@app.route('/admin')
def homeAdmin():
    return render_template('home.html')

@app.route('/welcome')
@login_required
def homeClient():
    return render_template('homeClient.html')

feedback_list = []

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        date_of_visit = request.form['date_of_visit']
        feedback = request.form['feedback']

        print("Preparing email...")  # Debugging
        try:
            msg = Message("New Contact Form Submission",
                          recipients=['testingrestaurant43@gmail.com'])
            msg.body = f"""
            Name: {name}
            Email: {email}
            Date of Visit: {date_of_visit}
            Feedback: {feedback}
            """

            print("Sending email...")  # Debugging
            mail.send(msg)
            print("Email sent!")  # Debugging

            flash("Your message has been sent successfully!", "success")
        except Exception as e:
            print("Email error:", str(e))  # Debugging
            flash(f"Error sending email: {str(e)}", "danger")

        time.sleep(1)  # Small delay to prevent overload
        return redirect(url_for('contact'))  # Redirect properly

    return render_template('contactUs2.html', feedback_list=feedback_list)


@app.route('/contactUs2')
def contact_us2():
    return render_template('contactUs2.html')

@app.route('/contactUs3')
def contact_us3():
    return render_template('contactUs3.html')

@app.route('/retrieveContacts')
@login_required
def retrieve_contacts():
    db = shelve.open('contact.db', 'r')
    contact_list = db.get('Contacts', [])  # Fetch stored contacts
    db.close()
    return render_template('ContactForms.html', contact_list=contact_list)


@app.route('/menu')
def menu():
    menu_items = {}
    db = shelve.open('menu.db', 'r')
    menu_items = db['MenuItems']
    db.close()
    menu_list = [menu_items[key] for key in menu_items]
    return render_template('menu.html', menu_list=menu_list)

@app.route('/createUser', methods=['GET', 'POST'])
@login_required
def create_user():
    create_user_form = CreateUserForm(request.form)
    if request.method == 'POST' and create_user_form.validate():
        users_dict = {}
        db = shelve.open('user.db', 'c')

        try:
            users_dict = db['Users']
        except:
            print("Error in retrieving Users from user.db.")

        user = User.User(
            create_user_form.first_name.data,
            create_user_form.last_name.data,
            create_user_form.email.data,
            create_user_form.phone.data
        )
        users_dict[user.get_user_id()] = user
        db['Users'] = users_dict
        db.close()

        return redirect(url_for('retrieve_users'))
    return render_template('createUser.html', form=create_user_form)

@app.route('/updateUser/<int:id>/', methods=['GET', 'POST'])
@login_required
def update_user(id):
    update_user_form = CreateUserForm(request.form)
    if request.method == 'POST':
        db = shelve.open('user.db', 'w')
        users_dict = db['Users']
        user = users_dict.get(id)
        user.set_first_name(update_user_form.first_name.data)
        user.set_last_name(update_user_form.last_name.data)
        user.set_email(update_user_form.email.data)
        user.set_phone(update_user_form.phone.data)
        user.set_privilege(update_user_form.userprivilege.data)
        users_dict[id] = user
        db['Users'] = users_dict
        db.close()
        return redirect(url_for('retrieve_users'))
    else:
        db = shelve.open('user.db', 'r')
        users_dict = db['Users']
        user = users_dict.get(id)
        update_user_form.first_name.data = user.get_first_name()
        update_user_form.last_name.data = user.get_last_name()
        update_user_form.email.data = user.get_email()
        update_user_form.phone.data = user.get_phone()
        update_user_form.userprivilege.data = user.get_privilege()
        db.close()
        return render_template('updateUser.html', form=update_user_form)

@app.route('/deleteUser/<int:id>', methods=['POST'])
@login_required
def delete_user(id):
    db = shelve.open('user.db', 'w')
    users_dict = db['Users']
    users_dict.pop(id)
    db['Users'] = users_dict
    db.close()
    return redirect(url_for('retrieve_users'))

@app.route('/retrieveUsers')
@login_required
def retrieve_users():
    users_dict = {}
    db = shelve.open('user.db', 'r')
    users_dict = db['Users']
    db.close()
    users_list = []
    for key in users_dict:
        user = users_dict.get(key)
        users_list.append(user)
    return render_template('retrieveUsers.html', count=len(users_list), users_list=users_list)

@app.route('/createMenuItem', methods=['GET', 'POST'])
@login_required
def create_menu_item():
    create_menu_item_form = CreateMenuItemForm(request.form)

    if request.method == 'POST' and create_menu_item_form.validate():
        db = shelve.open('menu.db', 'c')
        menu_items = db.get('MenuItems', {})

        new_id = max([0] + [item['id'] for item in menu_items.values()]) + 1

        # ✅ Image upload handling
        image_file = request.files['image']
        if image_file and allowed_file(image_file.filename):
            filename = secure_filename(image_file.filename)
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            image_file.save(image_path)  # ✅ Save image to static/images/
            image_url = f'images/{filename}'  # ✅ Store relative path
        else:
            image_url = 'images/placeholder.jpg'  # ✅ Default image if none uploaded

        menu_item = {
            'id': new_id,
            'name': create_menu_item_form.name.data,
            'description': create_menu_item_form.description.data,
            'price': create_menu_item_form.price.data,
            'category': create_menu_item_form.category.data,
            'image_url': image_url  # ✅ Store image path
        }

        menu_items[menu_item['id']] = menu_item
        db['MenuItems'] = menu_items
        db.close()

        return redirect(url_for('retrieve_menu_items'))

    return render_template('createMenuItem.html', form=create_menu_item_form)

@app.route('/retrieveMenuItems')
def retrieve_menu_items():
    menu_items = {}
    db = shelve.open('menu.db', 'r')
    menu_items = db['MenuItems']
    db.close()
    menu_list = [menu_items[key] for key in menu_items]
    return render_template('retrieveMenuItems.html', menu_list=menu_list)

@app.route('/updateMenuItem/<int:id>/', methods=['GET', 'POST'])
def update_menu_item(id):
    update_menu_item_form = CreateMenuItemForm(request.form)
    db = shelve.open('menu.db', 'w')
    menu_items = db['MenuItems']
    menu_item = menu_items.get(id)

    if request.method == 'POST' and update_menu_item_form.validate():
        # Update text fields
        menu_item['name'] = update_menu_item_form.name.data
        menu_item['description'] = update_menu_item_form.description.data
        menu_item['price'] = update_menu_item_form.price.data
        menu_item['category'] = update_menu_item_form.category.data

        # Handle Image Upload
        if 'image' in request.files:
            image_file = request.files['image']
            if image_file and allowed_file(image_file.filename):
                filename = secure_filename(image_file.filename)
                image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                image_file.save(image_path)  # Save the new image
                menu_item['image_url'] = f'images/{filename}'  # Update image URL in the database

        db['MenuItems'] = menu_items
        db.close()
        return redirect(url_for('retrieve_menu_items'))

    # Populate form fields with existing data
    update_menu_item_form.name.data = menu_item['name']
    update_menu_item_form.description.data = menu_item['description']
    update_menu_item_form.price.data = menu_item['price']
    update_menu_item_form.category.data = menu_item['category']

    db.close()
    return render_template('updateMenuItem.html', form=update_menu_item_form, menu_item=menu_item)

@app.route('/deleteMenuItem/<int:id>', methods=['POST'])
def delete_menu_item(id):
    db = shelve.open('menu.db', 'w')
    menu_items = db['MenuItems']
    menu_items.pop(id, None)
    db['MenuItems'] = menu_items
    db.close()
    return redirect(url_for('retrieve_menu_items'))

@app.route('/createOrder', methods=['GET', 'POST'])
def create_order():
    create_order_form = CreateOrderForm(request.form)

    db = shelve.open('menu.db', 'r')
    menu_items = db.get('MenuItems', {})
    db.close()

    create_order_form.menu_items.choices = [(key, menu_items[key]['name']) for key in menu_items]

    if request.method == 'POST':
        db = shelve.open('order.db', 'c')
        orders = db.get('Orders', {})

        selected_items = [menu_items[int(item_id)] for item_id in create_order_form.menu_items.data]
        total_price = sum(
            float(item['price'].replace('S$', '').strip()) for item in selected_items
        )

        new_order = Order(
            customer_name=create_order_form.customer_name.data,
            table_number=create_order_form.table_number.data,
            menu_items=selected_items,
            total_price=total_price,
            status=create_order_form.status.data
        )

        orders[new_order.get_order_id()] = {
            'id': new_order.get_order_id(),
            'customer_name': new_order.get_customer_name(),
            'table_number': new_order.get_table_number(),
            'menu_items': selected_items,
            'total_price': total_price,
            'status': new_order.get_status()
        }

        db['Orders'] = orders
        db.close()

        return redirect(url_for('retrieve_orders'))
    return render_template('createOrder.html', form=create_order_form)


@app.route('/retrieveOrders')
def retrieve_orders():
    db = shelve.open('order.db', 'r')
    orders = db.get('Orders', {})  # Fetch all orders as a dictionary
    db.close()

    # Convert the orders dictionary to a list of dictionaries
    orders_list = [{'id': order_id, **order_data} for order_id, order_data in orders.items()]

    return render_template('retrieveOrders.html', orders=orders_list)


@app.route('/updateOrder/<int:id>/', methods=['GET', 'POST'])
def update_order(id):
    form = CreateOrderForm()

    # Fetch menu items for the form
    db_menu = shelve.open('menu.db', 'r')
    menu_items = list(db_menu.get('MenuItems', {}).values())
    db_menu.close()

    # Fetch the existing order data
    db = shelve.open('order.db', 'r')
    orders = db.get('Orders', {})
    order = orders.get(id, {})
    db.close()

    if request.method == 'POST':
        # Debug: Print form data
        print("Form Data Received:")
        print(f"Customer Name: {form.customer_name.data}")
        print(f"Table Number: {form.table_number.data}")
        print(f"Status: {form.status.data}")

        # Parse the order items from the form
        order_items = json.loads(request.form.get('order_items', '[]'))
        print("Order Items:", order_items)

        # Calculate total price
        total_price = sum(item['price'] * item['quantity'] for item in order_items)
        print("Total Price:", total_price)

        # Update the order with the new data
        order.update({
            'customer_name': form.customer_name.data,
            'table_number': form.table_number.data,  # Ensure this is being updated
            'status': form.status.data,
            'menu_items': order_items,
            'total_price': total_price
        })

        # Save the updated order back to the database
        db = shelve.open('order.db', 'w')
        orders[id] = order
        db['Orders'] = orders
        db.close()

        print("Order Updated Successfully!")
        return redirect(url_for('retrieve_orders'))

    # Populate the form with existing order data
    if order:
        form.customer_name.data = order.get('customer_name', '')
        form.table_number.data = order.get('table_number', 'N/A')
        form.status.data = order.get('status', 'Pending')
        # Pre-select the menu items in the form
        form.menu_items.data = [str(item.get('id')) for item in order.get('menu_items', [])]

    return render_template('updateOrder.html',
                           form=form,
                           menu_items=menu_items,
                           order_data=order)

@app.route('/deleteOrder/<int:id>', methods=['POST'])
def delete_order(id):
    db = shelve.open('order.db', 'w')
    orders = db.get('Orders', {})
    orders.pop(id, None)
    db['Orders'] = orders
    db.close()
    return redirect(url_for('retrieve_orders'))

@app.route('/reservationHome')
def reservation_home():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    db = shelve.open('reservation.db', 'c')
    reservations = db.get('Reservations', {})
    db.close()

    # Filter reservations to only show the current user's reservations
    user_reservations = [res for res in reservations.values() if res.get_user_id() == user_id]

    return render_template('reservationHome.html', reservations=user_reservations , current_date=date.today())

@app.route('/createReservation', methods=['GET', 'POST'])
def create_reservation():
    form = CreateReservationForm(request.form)

    if request.method == 'POST':
        if form.validate():
            print("Form validated successfully!")  # Debugging
        else:
            print("Form validation failed:", form.errors)  # Debugging
            return render_template('reservationClient.html', form=form)  # Re-render form if invalid

        # Open database
        db = shelve.open('reservation.db', 'c')
        try:
            reservations = db.get('Reservations', {})  # Use .get() to avoid KeyError
        except Exception as e:
            print(f"Error opening database: {e}")  # Debugging
            reservations = {}

        # Create and store reservation
        reservation = Reservation(
            user_id=session.get('user_id'),
            customer_name=form.customer_name.data,
            dining_date=form.dining_date.data,
            time=form.time.data,
            party_size=form.party_size.data,
            remarks=form.remarks.data,
        )

        reservation_id = str(reservation.get_reservation_id())  # Ensure ID is a string for URL
        reservations[reservation_id] = reservation
        db['Reservations'] = reservations  # Save back to database
        db.close()

        # Debugging: Print the generated reservation ID
        print(f"Generated Reservation ID: {reservation_id}")

        # Redirect to confirmation page
        return redirect(url_for('reservation_confirmation', reservation_id=reservation_id))

    return render_template('reservationClient.html', form=form)



@app.route('/reservationConfirmation', methods=['GET'])
def reservation_confirmation():
    reservation_id = request.args.get('reservation_id')
    print(f"Reservation ID from URL: {reservation_id}")  # Debugging statement

    db = shelve.open('reservation.db', 'r')
    reservations = db.get('Reservations', {})
    reservation = reservations.get(reservation_id)
    db.close()

    if reservation is None:
        print("Reservation not found!")  # Debugging statement
        return "Reservation not found", 404

    print(f"Reservation found: {reservation}")  # Debugging statement
    return render_template('reservationConfirmation.html', reservation=reservation)


@app.route('/retrieveReservations')
def retrieve_reservations():
    db = shelve.open('reservation.db', 'r')
    reservations = db.get('Reservations', {})
    db.close()
    return render_template('retrieveReservation.html', reservations=reservations.values())


@app.route('/updateReservation/<int:id>/', methods=['GET', 'POST'])
def update_reservation(id):
    db = shelve.open('reservation.db', 'w')
    reservations = db.get('Reservations', {})

    # ✅ Convert id to string to match how shelve stores keys
    reservation = reservations.get(str(id))

    if not reservation:
        db.close()
        return redirect(url_for('reservation_home'))

    form = CreateReservationForm(request.form)

    if request.method == 'POST' and form.validate():
        reservation.set_customer_name(form.customer_name.data)
        reservation.set_dining_date(form.dining_date.data)
        reservation.set_time(form.time.data)
        reservation.set_party_size(form.party_size.data)
        reservation.set_remarks(form.remarks.data)

        db['Reservations'] = reservations
        db.close()
        return redirect(url_for('reservation_home'))

    # ✅ Pre-fill the form with existing reservation data
    form.customer_name.data = reservation.get_customer_name()
    form.dining_date.data = reservation.get_dining_date()
    form.time.data = reservation.get_time()
    form.party_size.data = reservation.get_party_size()
    form.remarks.data = reservation.get_remarks()

    db.close()
    return render_template('updateReservation.html', form=form)

@app.route('/deleteReservation/<int:id>', methods=['POST'])
def delete_reservation(id):
    db = shelve.open('reservation.db', 'w')
    reservations = db.get('Reservations', {})

    # ✅ Convert id to string for consistency
    if str(id) in reservations:
        del reservations[str(id)]
        db['Reservations'] = reservations
        db.close()
        flash("Reservation deleted successfully!", "success")
    else:
        db.close()
        flash("Error: Reservation not found!", "danger")

    return redirect(url_for('reservation_home'))

@app.route('/register', methods=['GET', 'POST'])
def register_user():
    create_user_form = CreateUserForm(request.form)
    if request.method == 'POST':
        db = shelve.open('user.db', 'c')
        users_dict = db.get('Users', {})

        # Find the next available user ID
        if users_dict:
            new_user_id = max(users_dict.keys()) + 1
        else:
            new_user_id = 1  # First user

        # Create the user with an explicit ID
        user = User.User(
            new_user_id,
            create_user_form.first_name.data,
            create_user_form.last_name.data,
            create_user_form.email.data,
            create_user_form.phone.data,
            create_user_form.username.data,
            create_user_form.userpassword.data,
            "client"
        )

        users_dict[new_user_id] = user
        db['Users'] = users_dict
        db.close()

        return redirect(url_for('login'))
    return render_template('registerPage.html', form=create_user_form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    login_form = LoginForm(request.form)

    if request.method == 'POST' and login_form.validate():
        db = shelve.open('user.db', 'r')
        users_dict = db.get('Users', {})
        db.close()

        for user_id, user in users_dict.items():
            if user.get_username() == login_form.username.data and user.get_password() == login_form.loginpassword.data:
                session['user_id'] = user_id  # Store user ID in session
                session['user_email'] = user.get_email()  # ✅ Store email in session

                if user.get_privilege() == 'admin':
                    return redirect(url_for('homeAdmin'))
                elif user.get_privilege() == 'client':
                    return redirect(url_for('homeClient'))

        flash('Invalid username or password.', 'danger')  # No third argument
        session['flash_login'] = True  # Set a session variable

    return render_template('loginPage.html', form=login_form)


@app.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
    try:
        # Clear the session data
        session.clear()
        # Flash a success message
        return redirect(url_for('home'))
    except Exception as e:
        # Log the error (if you have logging set up)
        print(f"Error during logout: {str(e)}")
        flash('An error occurred during logout.', 'error')
        return redirect(url_for('homeClient'))

@app.route('/order', methods=['GET', 'POST'])
def order():
    create_order_form = CreateOrderForm(request.form)
    db = shelve.open('menu.db', 'r')
    menu_items = db.get('MenuItems', {})
    db.close()

    create_order_form.menu_items.choices = [(str(key), menu_items[key]['name']) for key in menu_items]

    return render_template('order.html',
                           form=create_order_form,
                           menu_items=menu_items)

@app.route('/checkout', methods=['POST'])
def checkout():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'User not logged in'}), 400

    order_data = request.get_json()
    if not order_data or 'items' not in order_data:
        return jsonify({'success': False, 'message': 'Invalid order data'}), 400

    print(f"Received checkout data: {order_data}")  # Debugging

    db = shelve.open('order.db', 'c')
    orders = db.get('Orders', {})

    new_order_id = max(orders.keys(), default=0) + 1

    total_price = sum(item['price'] * item['quantity'] for item in order_data['items'])  # ✅ Ensure correct total

    new_order = {
        'id': new_order_id,
        'user_id': session['user_id'],
        'menu_items': order_data['items'],
        'total_price': total_price,  # ✅ Store the correct price
        'status': 'Pending Payment'
    }

    orders[new_order_id] = new_order
    db['Orders'] = orders
    db.close()

    session['order_id'] = new_order_id  # ✅ Store correct order ID
    session['order_data'] = new_order  # ✅ Store order data in session
    session.modified = True

    return jsonify({'success': True, 'message': 'Order stored. Proceed to payment.'})






@app.route('/reservation', methods=['GET', 'POST'])
@login_required
def reservation():
    form = CreateReservationForm(request.form)
    today = date.today().strftime('%Y-%m-%d')

    if request.method == 'POST' and form.validate():
        user_id = session['user_id']
        db = shelve.open('reservation.db', 'c')
        try:
            reservations = db['Reservations']
        except:
            reservations = {}

        reservation = Reservation(
            user_id=user_id,
            customer_name=form.customer_name.data,
            dining_date=form.dining_date.data,
            time=form.time.data,
            party_size=form.party_size.data,
            remarks=form.remarks.data
        )
        reservations[reservation.get_reservation_id()] = reservation
        db['Reservations'] = reservations
        db.close()
        return redirect(url_for('homeClient'))

    return render_template('reservationClient.html', form=form, today=today)


@app.route('/payment', methods=['GET', 'POST'])
def payment():
    if 'order_data' not in session:
        flash("No order found. Please add items to cart.", "danger")
        return redirect(url_for('order'))

    order_data = session['order_data']
    total_amount = round(float(order_data.get('total_price', 0)), 2)

    if request.method == 'POST':
        try:
            # Create Stripe checkout session
            checkout_session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[{
                    'price_data': {
                        'currency': 'usd',
                        'product_data': {
                            'name': 'Restaurant Order',
                        },
                        'unit_amount': int(total_amount * 100),
                    },
                    'quantity': 1,
                }],
                mode='payment',
                success_url=url_for('payment_confirmation', _external=True) + '?session_id={CHECKOUT_SESSION_ID}',
                cancel_url=url_for('order', _external=True),
            )

            return jsonify({'url': checkout_session.url})

        except Exception as e:
            return jsonify({'error': str(e)}), 500

    return render_template('payment.html', total_amount=total_amount)


@app.route('/payment_confirmation')
def payment_confirmation():
    session_id = request.args.get('session_id')

    if not session_id:
        flash('Payment session not found.', 'danger')
        return redirect(url_for('order'))

    try:
        # Retrieve the Stripe session
        stripe_session = stripe.checkout.Session.retrieve(session_id)

        if stripe_session.payment_status == 'paid':
            # Get order from session
            order_data = session.get('order_data')
            if order_data:
                # Update order status in database
                db = shelve.open('order.db', 'w')
                orders = db.get('Orders', {})
                order_id = order_data.get('id')

                if order_id in orders:
                    orders[order_id]['status'] = 'Paid'
                    db['Orders'] = orders

                db.close()

                # Clear the order from session
                session.pop('order_data', None)

                flash('Payment successful!', 'success')
                return render_template('paymentConfirmation.html',
                                       order_id=order_id,
                                       total_amount=stripe_session.amount_total / 100)

            flash('Order not found.', 'danger')
            return redirect(url_for('order'))

        flash('Payment not completed.', 'warning')
        return redirect(url_for('order'))

    except Exception as e:
        flash(f'Error processing payment: {str(e)}', 'danger')
        return redirect(url_for('order'))






@app.route('/orderClient')
@login_required
def retrieve_ordersClient():
    user_id = session.get('user_id')

    if not user_id:
        flash("You must be logged in to view orders!", "danger")
        return redirect(url_for('login'))

    db = shelve.open('order.db', 'r')
    orders = db.get('Orders', {})  # Fetch all orders as a dictionary
    db.close()

    # ✅ Filter orders to only include those from the logged-in user
    user_orders = [
        {'id': order_id, **order_data}
        for order_id, order_data in orders.items()
        if order_data.get('user_id') == user_id
    ]

    return render_template('orderClient.html', orders=user_orders)


@app.route('/updateOrderClient/<int:id>/', methods=['GET', 'POST'])
def update_orderClient(id):
    form = CreateOrderForm()

    # Fetch menu items for the form
    db_menu = shelve.open('menu.db', 'r')
    menu_items = list(db_menu.get('MenuItems', {}).values())
    db_menu.close()

    # Fetch the existing order data
    db = shelve.open('order.db', 'r')
    orders = db.get('Orders', {})
    order = orders.get(id, {})
    db.close()

    if request.method == 'POST':
        # Debug: Print form data
        print("Form Data Received:")
        print(f"Customer Name: {form.customer_name.data}")
        print(f"Table Number: {form.table_number.data}")
        print(f"Status: {form.status.data}")

        # Parse the order items from the form
        order_items = json.loads(request.form.get('order_items', '[]'))
        print("Order Items:", order_items)

        # Calculate total price
        total_price = sum(item['price'] * item['quantity'] for item in order_items)
        print("Total Price:", total_price)

        # Update the order with the new data
        order.update({
            'customer_name': form.customer_name.data,
            'table_number': form.table_number.data,  # Ensure this is being updated
            'status': form.status.data,
            'menu_items': order_items,
            'total_price': total_price
        })

        # Save the updated order back to the database
        db = shelve.open('order.db', 'w')
        orders[id] = order
        db['Orders'] = orders
        db.close()

        print("Order Updated Successfully!")
        return redirect(url_for('retrieve_ordersClient'))

    # Populate the form with existing order data
    if order:
        form.customer_name.data = order.get('customer_name', '')
        form.table_number.data = order.get('table_number', 'N/A')
        form.status.data = order.get('status', 'Paid')
        # Pre-select the menu items in the form
        form.menu_items.data = [str(item.get('id')) for item in order.get('menu_items', [])]

    return render_template('updateOrderClient.html',
                           form=form,
                           menu_items=menu_items,
                           order_data=order)



@app.route('/deleteOrderClient/<int:id>', methods=['POST'])
def delete_orderClient(id):
    db = shelve.open('order.db', 'w')
    orders = db.get('Orders', {})
    orders.pop(id, None)
    db['Orders'] = orders
    db.close()
    return redirect(url_for('retrieve_ordersClient'))

if __name__ == '__main__':
    app.run(debug=True)

