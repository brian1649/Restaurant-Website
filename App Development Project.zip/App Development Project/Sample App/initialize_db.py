import shelve

db = shelve.open('order.db', 'c')
if 'Orders' not in db:
    db['Orders'] = {}
    print("Initialized 'Orders' in order.db")
db.close()
